# tensorflow-quarterback-projection
This is a neural network classifying quarterbacks as NFL-ready or busts based on college data and the teams that draft them.
